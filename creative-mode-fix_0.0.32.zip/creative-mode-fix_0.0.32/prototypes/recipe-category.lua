data:extend(
{
	{
		-- Free fluids
		type = "recipe-category",
		name = creative_mode_defines.names.recipe_categories.free_fluids
	},
	{
		-- Energy absorption
		type = "recipe-category",
		name = creative_mode_defines.names.recipe_categories.energy_absorption
	}
})